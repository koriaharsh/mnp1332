import React from "react";
import DashboardSmallCards from "../Cards/DashboardSmallCards";
import { AiOutlineUserAdd } from "react-icons/ai";
import { BiTask } from "react-icons/bi";
import { AiOutlineUserSwitch } from "react-icons/ai";
import { AiOutlineUserDelete } from "react-icons/ai";
import { useEffect } from "react";
import { useState } from "react";
import axios from "axios";

function Dashboard() {
  const [counts, setCounte] = useState({});
  useEffect(() => {
    axios
      .get("http://10.224.1.212:8000/admin/counts", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log(response.data);
        setCounte(response.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  return (
    <div className="container">
      <div className="d-flex flex-row justify-content-around mt-5">
        <DashboardSmallCards
          width="20%"
          title="Active Users"
          icon={AiOutlineUserAdd}
          value={counts?.active}
          color="#6e79de"
        />
        <DashboardSmallCards
          width="20%"
          title="Inactive Users"
          icon={AiOutlineUserDelete}
          value={counts?.in_active}
          color="#d42d1d"
        />
        <DashboardSmallCards
          width="20%"
          title="Tasks"
          icon={BiTask}
          value="25"
          color="#3b6430"
        />
        <DashboardSmallCards
          width="20%"
          title="Live Users"
          icon={AiOutlineUserSwitch}
          value="25"
          color="#593c72"
        />
      </div>
    </div>
  );
}

export default Dashboard;
